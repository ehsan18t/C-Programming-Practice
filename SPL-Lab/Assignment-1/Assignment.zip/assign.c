#include <stdio.h>
#include <string.h>

struct student_marks {
    char id[10];
    int bangla;
    int english;
    int math;
};

float calc_grade(int mark) {
    // return the grade according to mark
    // 100-80: 4.00
    // 79-75: 3.75
    // 74-70: 3.50
    // 69-65: 3.25
    // 64-60: 3.00
    // 59-55: 2.75
    // 54-50: 2.50
    // 49-45: 2.25
    // 44-40: 2.00
    // 39-0: 0.00
    // write your code here





}

void make_gradesheet(struct student_marks X) {
    // create a text file named after student' id with necessary grading information
    // write your code here






}

int main() {
    FILE* fp;

    fp = fopen("marks.txt", "r");
    if(fp == NULL) {
        printf("file does not exist\n");
        exit(0);
    }

    // take input from the input file
    // store it in a structure
    // and process it with make_gradesheet function
    // write your code here





    fclose(fp);

    return 0;
}
